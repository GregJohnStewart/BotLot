#!/bin/bash
/home/pi/diddyborg/diddyJoy.py > /dev/null

