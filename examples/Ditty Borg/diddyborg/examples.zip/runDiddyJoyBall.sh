#!/bin/bash
/home/pi/diddyborg/diddyJoyBall.py > /dev/null

